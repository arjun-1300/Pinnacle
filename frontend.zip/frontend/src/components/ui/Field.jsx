// components/ui/Field.jsx — Labelled form field with unit affix
import { cn } from '../../lib/cn'

export function Field({ id, label, value, onChange, min, max, step = '0.1', unit, className }) {
  return (
    <div className={cn('field', className)}>
      <label className="field-label" htmlFor={id}>{label}</label>
      <div className="field-input-wrap">
        <input
          id={id}
          type="number"
          className={cn('field-input', unit && 'has-unit')}
          value={value}
          min={min}
          max={max}
          step={step}
          onChange={e => onChange(e.target.value)}
          placeholder={`e.g. ${min}`}
          autoComplete="off"
        />
        {unit && <span className="field-unit">{unit}</span>}
      </div>
    </div>
  )
}

// components/layout/Navbar.jsx — Clinical app header
import { useState, useEffect } from 'react'
import { Activity, Sun, Moon } from 'lucide-react'

export function Navbar({ serverOnline }) {
  const [dark, setDark] = useState(() => {
    const stored = localStorage.getItem('pinnacle-theme')
    if (stored) return stored === 'dark'
    return window.matchMedia('(prefers-color-scheme: dark)').matches
  })

  useEffect(() => {
    const meta = document.querySelector('meta[name="color-scheme"]')
      ?? Object.assign(document.createElement('meta'), { name: 'color-scheme' })
    if (!meta.parentElement) document.head.appendChild(meta)
    meta.content = dark ? 'dark' : 'light'
    localStorage.setItem('pinnacle-theme', dark ? 'dark' : 'light')
  }, [dark])

  return (
    <nav className="navbar" role="banner">
      {/* Brand */}
      <div className="navbar-brand">
        <div className="navbar-logo" aria-hidden="true">
          <Activity size={18} color="#fff" strokeWidth={2.5} />
        </div>
        <div className="navbar-brand-text">
          <span className="navbar-brand-title">Pinnacle</span>
          <span className="navbar-brand-sub">Clinical Multi-Agent Monitoring</span>
        </div>
      </div>

      {/* Right actions */}
      <div className="navbar-actions">
        {/* API status */}
        <div
          className={`api-status-badge ${serverOnline ? 'online' : 'offline'}`}
          title={serverOnline ? 'Backend connected on :8001' : 'Backend unreachable'}
          aria-label={`API ${serverOnline ? 'connected' : 'offline'}`}
        >
          <span className="api-pulse" />
          {serverOnline ? '● API Connected :8001' : '● API Offline'}
        </div>

        {/* Dark/light toggle */}
        <button
          id="theme-toggle"
          className="theme-toggle-btn"
          onClick={() => setDark(d => !d)}
          aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'}
          title={dark ? 'Light mode' : 'Dark mode'}
        >
          {dark ? <Sun size={16} /> : <Moon size={16} />}
        </button>
      </div>
    </nav>
  )
}

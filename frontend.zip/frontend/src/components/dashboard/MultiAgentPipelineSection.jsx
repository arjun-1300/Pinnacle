// components/dashboard/MultiAgentPipelineSection.jsx — Comprehensive 4-Agent Pipeline Breakdown
import { useState } from 'react'
import {
  Activity,
  Pill,
  Brain,
  ShieldCheck,
  ShieldAlert,
  Sparkles,
  Cpu,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  FileText,
  ChevronDown,
  ChevronUp,
  Sliders,
  Layers,
  HeartPulse
} from 'lucide-react'
import { cn } from '../../lib/cn'

export function MultiAgentPipelineSection({ result }) {
  const [selectedAgent, setSelectedAgent] = useState('all') // 'all' or 1, 2, 3, 4
  const [collapsed, setCollapsed] = useState(false)

  // Agent specifications and data mapping
  const agents = [
    {
      id: 1,
      key: 'monitoring_agent',
      num: '01',
      title: 'Physiological Monitoring Agent',
      shortName: 'Monitoring',
      icon: <Activity size={18} />,
      color: '#10b981', // emerald
      bgColor: 'rgba(16, 185, 129, 0.1)',
      borderColor: 'rgba(16, 185, 129, 0.25)',
      isLlm: result?.agent_llm_status?.monitoring_agent,
      techLabel: result?.agent_llm_status?.monitoring_agent ? 'Gemini 3 Flash' : 'RandomForest Classifier',
      whatItDoes: 'Ingests real-time biometric vitals streams (HR, SpO2, Temp, SBP), detects physiological anomalies, and stratifies patient hemodynamic instability into clinical risk tiers.',
      inputsProcessed: result?.vitals ? [
        { label: 'Heart Rate', value: `${result.vitals.heart_rate} bpm` },
        { label: 'Blood Oxygen (SpO₂)', value: `${result.vitals.spo2}%` },
        { label: 'Temperature', value: `${result.vitals.temperature}°C` },
        { label: 'Systolic BP', value: `${result.vitals.systolic_bp} mmHg` },
      ] : null,
      clinicalReasoning: result?.monitoring_reasoning || 'Awaiting physiological vitals ingest to analyze organ stress and hemodynamic stability.',
      outputSummary: result ? {
        headline: `Risk Classification: ${result.predicted_risk}`,
        detail: `Confidence: ${Math.round((result.confidence || 0) * 100)}%`,
        tag: result.predicted_risk,
        tagColor: result.predicted_risk === 'Critical' ? 'var(--risk-critical)' : result.predicted_risk === 'Warning' ? 'var(--risk-warning)' : 'var(--risk-normal)',
      } : null,
    },
    {
      id: 2,
      key: 'medication_agent',
      num: '02',
      title: 'Pharmacovigilance & Medication Agent',
      shortName: 'Pharmacology',
      icon: <Pill size={18} />,
      color: '#f59e0b', // amber
      bgColor: 'rgba(245, 158, 11, 0.1)',
      borderColor: 'rgba(245, 158, 11, 0.25)',
      isLlm: result?.agent_llm_status?.medication_agent,
      techLabel: result?.agent_llm_status?.medication_agent ? 'Gemini 3 Flash' : 'DDI Rules Engine',
      whatItDoes: 'Conducts automated pharmacological cross-referencing against active patient medications and documented drug allergies to preempt drug-drug interactions (DDIs) and generate contraindication boundaries.',
      inputsProcessed: result ? [
        { label: 'Active Meds', value: result.current_medications?.length ? result.current_medications.join(', ') : 'None' },
        { label: 'Known Allergies', value: result.known_allergies?.length ? result.known_allergies.join(', ') : 'None' },
        { label: 'Risk Context', value: result.predicted_risk || 'Normal' },
      ] : null,
      clinicalReasoning: result?.medication_reasoning || 'Evaluates pharmacological risks, enzyme competitive inhibition, and additive bleeding or nephrotoxic liabilities.',
      outputSummary: result ? {
        headline: result.interaction_warnings?.length ? `${result.interaction_warnings.length} Interaction Warning(s)` : 'No DDI Conflicts Found',
        detail: result.avoid_list?.length ? `Contraindicated: ${result.avoid_list.join(', ')}` : 'Safe profile',
        tag: result.interaction_warnings?.length ? 'DDI Flagged' : 'Cleared',
        tagColor: result.interaction_warnings?.length ? 'var(--risk-warning)' : 'var(--risk-normal)',
      } : null,
    },
    {
      id: 3,
      key: 'decision_agent',
      num: '03',
      title: 'Clinical Decision & Intervention Agent',
      shortName: 'Decision Logic',
      icon: <Brain size={18} />,
      color: '#6366f1', // indigo
      bgColor: 'rgba(99, 102, 241, 0.1)',
      borderColor: 'rgba(99, 102, 241, 0.25)',
      isLlm: result?.agent_llm_status?.decision_agent,
      techLabel: result?.agent_llm_status?.decision_agent ? 'Gemini 3 Flash' : 'Clinical Heuristic Engine',
      whatItDoes: 'Synthesizes biometric acuity and pharmacological constraints to formulate prioritized clinical action plans, diagnostic workup orders, and therapeutic drug candidates.',
      inputsProcessed: result ? [
        { label: 'Acuity Tier', value: result.predicted_risk || 'Normal' },
        { label: 'Pharmacology Filter', value: `${result.avoid_list?.length || 0} drugs restricted` },
        { label: 'Hemodynamic State', value: `${result.vitals?.heart_rate || '--'} HR / ${result.vitals?.spo2 || '--'}% SpO2` },
      ] : null,
      clinicalReasoning: result?.clinical_rationale || 'Synthesizing evidence-based guidelines and contraindication filters to formulate therapeutic strategy.',
      outputSummary: result ? {
        headline: result.candidate_drug ? `Candidate Drug: ${result.candidate_drug}` : 'Supportive Monitoring Protocol',
        detail: `${result.suggested_actions?.length || 0} Action Items Recommended`,
        tag: `${result.suggested_actions?.length || 0} Actions`,
        tagColor: 'var(--accent-light)',
      } : null,
    },
    {
      id: 4,
      key: 'safety_agent',
      num: '04',
      title: 'Safety Interceptor & Regulatory Gatekeeper',
      shortName: 'Safety Gate',
      icon: result?.drug_blocked ? <ShieldAlert size={18} /> : <ShieldCheck size={18} />,
      color: result?.drug_blocked ? '#ef4444' : '#10b981', // red or emerald
      bgColor: result?.drug_blocked ? 'rgba(239, 68, 68, 0.1)' : 'rgba(16, 185, 129, 0.1)',
      borderColor: result?.drug_blocked ? 'rgba(239, 68, 68, 0.3)' : 'rgba(16, 185, 129, 0.25)',
      isLlm: result?.agent_llm_status?.safety_agent,
      techLabel: result?.agent_llm_status?.safety_agent ? 'Gemini 3 Flash' : 'Deterministic Safety Barrier',
      whatItDoes: 'Acts as an independent zero-tolerance safety firewall that audits proposed medications against allergy profiles and severe DDIs, forcefully blocking dangerous orders before physician sign-off.',
      inputsProcessed: result ? [
        { label: 'Audited Drug', value: result.candidate_drug || 'None' },
        { label: 'Patient Allergies', value: result.known_allergies?.length ? result.known_allergies.join(', ') : 'None' },
        { label: 'Contraindication List', value: result.avoid_list?.length ? result.avoid_list.join(', ') : 'None' },
      ] : null,
      clinicalReasoning: result?.safety_reasoning || 'Verifies drug safety margins, absence of black-box contraindications, and absence of active allergen triggers.',
      outputSummary: result ? {
        headline: result.drug_blocked ? `INTERCEPTED: Blocked ${result.candidate_drug}` : (result.final_drug ? `CLEARED: ${result.final_drug} Safe` : 'Verified Safe'),
        detail: result.drug_blocked ? result.block_reason || 'Severe clinical contraindication' : 'Zero contraindications detected',
        tag: result.drug_blocked ? '🛑 BLOCKED' : '✅ CLEARED',
        tagColor: result.drug_blocked ? 'var(--risk-critical)' : 'var(--risk-normal)',
      } : null,
    },
  ]

  const activeAgents = selectedAgent === 'all'
    ? agents
    : agents.filter(a => a.id === Number(selectedAgent))

  return (
    <div id="multi-agent-pipeline" className="card animate-slide-up" style={{ marginTop: 16 }}>
      {/* ── Card Header ────────────────────────────────────────────── */}
      <div className="card-header" style={{ marginBottom: 16 }}>
        <div className="card-title-row">
          <span className="card-eyebrow">
            <span className="card-eyebrow-dot" style={{ background: 'var(--accent)' }} />
            Autonomous Multi-Agent Architecture
          </span>
          <span className="badge badge-accent" style={{ fontSize: '0.66rem', padding: '2px 8px' }}>
            <Sparkles size={11} style={{ marginRight: 4 }} />
            4 Active Agents
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {/* Filter Pills */}
          <div style={{
            display: 'flex',
            background: 'var(--bg-elevated)',
            padding: 3,
            borderRadius: 'var(--r-md)',
            border: '1px solid var(--border)',
            gap: 2,
          }}>
            <button
              onClick={() => setSelectedAgent('all')}
              style={{
                background: selectedAgent === 'all' ? 'var(--accent)' : 'transparent',
                color: selectedAgent === 'all' ? '#fff' : 'var(--text-muted)',
                border: 'none',
                borderRadius: 'var(--r-sm)',
                padding: '4px 10px',
                fontSize: '0.68rem',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.15s ease',
              }}
            >
              All 4 Agents
            </button>
            {agents.map((ag) => (
              <button
                key={ag.id}
                onClick={() => setSelectedAgent(ag.id)}
                style={{
                  background: selectedAgent === ag.id ? 'var(--accent)' : 'transparent',
                  color: selectedAgent === ag.id ? '#fff' : 'var(--text-muted)',
                  border: 'none',
                  borderRadius: 'var(--r-sm)',
                  padding: '4px 8px',
                  fontSize: '0.68rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                }}
              >
                {ag.num}
              </button>
            ))}
          </div>

          {/* Collapse/Expand Toggle */}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="btn btn-ghost"
            style={{ padding: '4px 8px', fontSize: '0.72rem', height: 28 }}
            title={collapsed ? 'Expand Pipeline' : 'Collapse Pipeline'}
          >
            {collapsed ? <ChevronDown size={15} /> : <ChevronUp size={15} />}
          </button>
        </div>
      </div>

      {/* ── Subtitle explanation ───────────────────────────────────── */}
      <div style={{
        fontSize: '0.78rem',
        color: 'var(--text-secondary)',
        lineHeight: 1.5,
        marginBottom: 16,
      }}>
        Sequential collaborative intelligence: Each specialized agent independently evaluates biometric telemetry, cross-checks clinical constraints, and enforces real-time governance.
      </div>

      {/* ── Pipeline Stepper Flow Bar ──────────────────────────────── */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: 8,
        marginBottom: 18,
      }}>
        {agents.map((ag, idx) => {
          const isSelected = selectedAgent === 'all' || selectedAgent === ag.id
          return (
            <div
              key={ag.id}
              onClick={() => setSelectedAgent(ag.id === selectedAgent ? 'all' : ag.id)}
              style={{
                cursor: 'pointer',
                padding: '10px 12px',
                borderRadius: 'var(--r-md)',
                background: isSelected ? ag.bgColor : 'var(--bg-elevated)',
                border: `1px solid ${isSelected ? ag.borderColor : 'var(--border)'}`,
                transition: 'all 0.2s ease',
                display: 'flex',
                flexDirection: 'column',
                gap: 4,
                position: 'relative',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{
                  fontSize: '0.64rem',
                  fontWeight: 800,
                  letterSpacing: '0.06em',
                  color: ag.color,
                }}>
                  AGENT {ag.num}
                </span>
                <span style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 3,
                  fontSize: '0.60rem',
                  padding: '1px 6px',
                  borderRadius: 12,
                  background: ag.isLlm ? 'rgba(99, 102, 241, 0.2)' : 'rgba(255, 255, 255, 0.05)',
                  color: ag.isLlm ? 'var(--accent-light)' : 'var(--text-muted)',
                  fontWeight: 700,
                }}>
                  {ag.isLlm ? '✨ LLM' : 'RULE'}
                </span>
              </div>

              <div style={{
                fontSize: '0.76rem',
                fontWeight: 700,
                color: 'var(--text-primary)',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
              }}>
                {ag.shortName}
              </div>

              <div style={{
                fontSize: '0.66rem',
                color: 'var(--text-muted)',
                lineHeight: 1.2,
                marginTop: 2,
              }}>
                {result ? (ag.outputSummary?.tag || 'Evaluated') : 'Ready'}
              </div>
            </div>
          )
        })}
      </div>

      {/* ── Expandable Agent Cards Container ───────────────────────── */}
      {!collapsed && (
        <div style={{
          display: 'grid',
          gridTemplateColumns: selectedAgent === 'all' ? 'repeat(auto-fit, minmax(320px, 1fr))' : '1fr',
          gap: 14,
        }}>
          {activeAgents.map((agent) => (
            <div
              key={agent.id}
              style={{
                borderRadius: 'var(--r-lg)',
                background: 'var(--bg-elevated)',
                border: `1px solid ${agent.borderColor}`,
                padding: '16px 18px',
                display: 'flex',
                flexDirection: 'column',
                gap: 12,
                position: 'relative',
                overflow: 'hidden',
              }}
            >
              {/* Agent Title + Tech Pill Header */}
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{
                    width: 36,
                    height: 36,
                    borderRadius: 'var(--r-md)',
                    background: agent.bgColor,
                    color: agent.color,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    border: `1px solid ${agent.borderColor}`,
                    flexShrink: 0,
                  }}>
                    {agent.icon}
                  </div>
                  <div>
                    <div style={{
                      fontSize: '0.64rem',
                      fontWeight: 800,
                      textTransform: 'uppercase',
                      letterSpacing: '0.08em',
                      color: agent.color,
                    }}>
                      Agent {agent.num} Pipeline Step
                    </div>
                    <div style={{
                      fontSize: '0.86rem',
                      fontWeight: 700,
                      color: 'var(--text-primary)',
                      lineHeight: 1.3,
                    }}>
                      {agent.title}
                    </div>
                  </div>
                </div>

                {/* Tech badge */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 4,
                  fontSize: '0.64rem',
                  fontWeight: 700,
                  padding: '3px 8px',
                  borderRadius: 12,
                  background: agent.isLlm ? 'rgba(99, 102, 241, 0.15)' : 'rgba(255, 255, 255, 0.05)',
                  border: `1px solid ${agent.isLlm ? 'rgba(99, 102, 241, 0.3)' : 'var(--border)'}`,
                  color: agent.isLlm ? 'var(--accent-light)' : 'var(--text-muted)',
                  whiteSelf: 'flex-start',
                }}>
                  {agent.isLlm ? <Sparkles size={11} /> : <Cpu size={11} />}
                  <span>{agent.techLabel}</span>
                </div>
              </div>

              {/* SECTION 1: What this Agent Does */}
              <div style={{
                background: 'var(--bg-card)',
                borderRadius: 'var(--r-md)',
                padding: '10px 12px',
                border: '1px solid var(--border)',
              }}>
                <div style={{
                  fontSize: '0.66rem',
                  fontWeight: 800,
                  textTransform: 'uppercase',
                  letterSpacing: '0.07em',
                  color: 'var(--text-muted)',
                  marginBottom: 4,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 5,
                }}>
                  <Sliders size={12} style={{ color: agent.color }} />
                  What This Agent Does
                </div>
                <div style={{
                  fontSize: '0.76rem',
                  lineHeight: 1.45,
                  color: 'var(--text-secondary)',
                }}>
                  {agent.whatItDoes}
                </div>
              </div>

              {/* SECTION 2: Ingested Inputs Processed */}
              {agent.inputsProcessed && (
                <div>
                  <div style={{
                    fontSize: '0.66rem',
                    fontWeight: 800,
                    textTransform: 'uppercase',
                    letterSpacing: '0.07em',
                    color: 'var(--text-muted)',
                    marginBottom: 6,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 5,
                  }}>
                    <Layers size={12} style={{ color: agent.color }} />
                    Inputs Ingested & Evaluated
                  </div>
                  <div style={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    gap: 6,
                  }}>
                    {agent.inputsProcessed.map((inp, i) => (
                      <div
                        key={i}
                        style={{
                          fontSize: '0.70rem',
                          padding: '4px 8px',
                          borderRadius: 'var(--r-sm)',
                          background: 'var(--bg-card)',
                          border: '1px solid var(--border)',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 6,
                        }}
                      >
                        <span style={{ color: 'var(--text-muted)' }}>{inp.label}:</span>
                        <strong style={{ color: 'var(--text-primary)', fontFamily: 'var(--font-mono)' }}>
                          {inp.value}
                        </strong>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* SECTION 3: Live Clinical Reasoning (Gemini or Rule Engine) */}
              <div style={{
                borderRadius: 'var(--r-md)',
                background: 'rgba(0,0,0,0.22)',
                padding: '10px 12px',
                borderLeft: `3px solid ${agent.color}`,
              }}>
                <div style={{
                  fontSize: '0.66rem',
                  fontWeight: 800,
                  textTransform: 'uppercase',
                  letterSpacing: '0.07em',
                  color: agent.color,
                  marginBottom: 4,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                    <FileText size={12} />
                    Agent Clinical Reasoning
                  </span>
                  {agent.isLlm && (
                    <span style={{ fontSize: '0.60rem', color: 'var(--accent-light)', textTransform: 'none' }}>
                      Live Synthesis
                    </span>
                  )}
                </div>
                <div style={{
                  fontSize: '0.75rem',
                  lineHeight: 1.5,
                  color: 'var(--text-secondary)',
                  fontStyle: result ? 'normal' : 'italic',
                }}>
                  {agent.clinicalReasoning}
                </div>
              </div>

              {/* SECTION 4: Output / Decision Verdict */}
              {agent.outputSummary && (
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '8px 12px',
                  borderRadius: 'var(--r-md)',
                  background: agent.bgColor,
                  border: `1px solid ${agent.borderColor}`,
                  marginTop: 'auto',
                }}>
                  <div>
                    <div style={{
                      fontSize: '0.74rem',
                      fontWeight: 700,
                      color: 'var(--text-primary)',
                    }}>
                      {agent.outputSummary.headline}
                    </div>
                    <div style={{
                      fontSize: '0.66rem',
                      color: 'var(--text-secondary)',
                    }}>
                      {agent.outputSummary.detail}
                    </div>
                  </div>
                  <span style={{
                    fontSize: '0.66rem',
                    fontWeight: 800,
                    padding: '2px 8px',
                    borderRadius: 10,
                    background: agent.outputSummary.tagColor,
                    color: '#fff',
                    flexShrink: 0,
                  }}>
                    {agent.outputSummary.tag}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

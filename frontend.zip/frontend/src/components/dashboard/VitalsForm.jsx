// components/dashboard/VitalsForm.jsx — Patient vitals input with presets and chip selectors
import { useState, useCallback } from 'react'
import { Zap, Heart, Thermometer, Activity, Pill, AlertTriangle } from 'lucide-react'
import { Field }   from '../ui/Field'
import { Button }  from '../ui/Button'
import { Spinner } from '../ui/Spinner'
import { api }     from '../../api'

const MEDS_OPTIONS    = ['warfarin', 'lisinopril', 'metformin']
const ALLERGY_OPTIONS = ['aspirin', 'ibuprofen']

const PRESETS = {
  normal: {
    label:       '✦ Normal Baseline',
    description: 'HR 75 · SpO₂ 98 · 36.8°C · 120 mmHg',
    vitals: { heart_rate: '75', spo2: '98', temperature: '36.8', systolic_bp: '120' },
    meds: [], allergies: [],
  },
  critical: {
    label:       '⚠ Critical Case',
    description: 'HR 125 · SpO₂ 89 · 39.3°C · 160 mmHg + Warfarin',
    vitals: { heart_rate: '125', spo2: '89', temperature: '39.3', systolic_bp: '160' },
    meds: ['warfarin'], allergies: [],
  },
}

function Chip({ label, active, type = 'med', onToggle }) {
  const activeClass = type === 'med' ? 'active-med' : 'active-allergy'
  return (
    <button
      type="button"
      className={`chip ${active ? activeClass : ''}`}
      onClick={onToggle}
      aria-pressed={active}
    >
      {active && <span className="chip-check">✓</span>}
      {label}
    </button>
  )
}

export function VitalsForm({ onAnalyze, loading }) {
  const [vitals, setVitals] = useState({
    heart_rate: '', spo2: '', temperature: '', systolic_bp: '',
  })
  const [meds,      setMeds]      = useState([])
  const [allergies, setAllergies] = useState([])
  const [simLoading, setSimLoading] = useState(false)
  const [simLabel,   setSimLabel]   = useState(null)

  function setVital(key) {
    return (val) => setVitals(v => ({ ...v, [key]: val }))
  }

  function toggleItem(list, setList, item) {
    setList(prev => prev.includes(item) ? prev.filter(x => x !== item) : [...prev, item])
  }

  function applyPreset(key) {
    const p = PRESETS[key]
    setVitals(p.vitals)
    setMeds(p.meds)
    setAllergies(p.allergies)
    setSimLabel(null)
  }

  async function loadSimulated() {
    setSimLoading(true)
    setSimLabel(null)
    try {
      const data = await api.simulate()
      setVitals({
        heart_rate:  String(data.heart_rate),
        spo2:        String(data.spo2),
        temperature: String(data.temperature),
        systolic_bp: String(data.systolic_bp),
      })
      setMeds(data.current_meds ?? [])
      setAllergies(data.allergies ?? [])
      setSimLabel(data.true_label)
    } catch (err) {
      console.error('Simulate failed:', err)
    } finally {
      setSimLoading(false)
    }
  }

  const handleAnalyze = useCallback(() => {
    onAnalyze({
      heart_rate:   parseFloat(vitals.heart_rate),
      spo2:         parseFloat(vitals.spo2),
      temperature:  parseFloat(vitals.temperature),
      systolic_bp:  parseFloat(vitals.systolic_bp),
      current_meds: meds,
      allergies,
    })
  }, [vitals, meds, allergies, onAnalyze])

  const isValid = Object.values(vitals).every(v => v !== '' && !isNaN(parseFloat(v)))

  return (
    <div className="card animate-slide-up">
      {/* Header */}
      <div className="card-header">
        <div className="card-title-row">
          <span className="card-eyebrow">
            <span className="card-eyebrow-dot" />
            Patient Input
          </span>
        </div>
      </div>

      {/* Preset buttons */}
      <div className="preset-bar">
        <button
          id="simulate-btn"
          type="button"
          className="preset-btn"
          onClick={loadSimulated}
          disabled={simLoading}
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
        >
          {simLoading
            ? <><Spinner size="sm" dark /> Loading…</>
            : <><Zap size={12} /> Simulate Random</>
          }
        </button>
        <button
          id="preset-normal-btn"
          type="button"
          className="preset-btn preset-normal"
          onClick={() => applyPreset('normal')}
        >
          <Heart size={11} style={{ display: 'inline', marginRight: 4 }} />
          Normal Baseline
        </button>
        <button
          id="preset-critical-btn"
          type="button"
          className="preset-btn preset-critical"
          onClick={() => applyPreset('critical')}
        >
          <AlertTriangle size={11} style={{ display: 'inline', marginRight: 4 }} />
          Critical Case
        </button>
      </div>

      {/* Simulated class hint */}
      {simLabel && (
        <div className="sim-hint">
          <Zap size={12} />
          Simulated class: <strong>{simLabel}</strong>
        </div>
      )}

      {/* Vitals inputs */}
      <div className="form-grid-2" style={{ marginBottom: 20 }}>
        <Field id="hr-input"   label="Heart Rate"   unit="bpm"  value={vitals.heart_rate}  onChange={setVital('heart_rate')}  min={20}  max={250} step="1" />
        <Field id="spo2-input" label="SpO₂"         unit="%"    value={vitals.spo2}         onChange={setVital('spo2')}         min={50}  max={100} step="0.1" />
        <Field id="temp-input" label="Temperature"  unit="°C"   value={vitals.temperature}  onChange={setVital('temperature')}  min={34}  max={43}  step="0.01" />
        <Field id="sbp-input"  label="Systolic BP"  unit="mmHg" value={vitals.systolic_bp}  onChange={setVital('systolic_bp')}  min={60}  max={250} step="1" />
      </div>

      {/* Medications */}
      <div style={{ marginBottom: 14 }}>
        <div className="section-label" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <Pill size={11} /> Current Medications
        </div>
        <div className="chip-group">
          {MEDS_OPTIONS.map(m => (
            <Chip key={m} label={m} type="med"
              active={meds.includes(m)}
              onToggle={() => toggleItem(meds, setMeds, m)}
            />
          ))}
        </div>
      </div>

      {/* Allergies */}
      <div style={{ marginBottom: 22 }}>
        <div className="section-label" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <AlertTriangle size={11} /> Known Allergies
        </div>
        <div className="chip-group">
          {ALLERGY_OPTIONS.map(a => (
            <Chip key={a} label={a} type="allergy"
              active={allergies.includes(a)}
              onToggle={() => toggleItem(allergies, setAllergies, a)}
            />
          ))}
        </div>
      </div>

      {/* Analyze */}
      <Button
        id="analyze-btn"
        variant="primary"
        full
        loading={loading}
        disabled={!isValid}
        onClick={handleAnalyze}
      >
        <Activity size={15} />
        Run Multi-Agent Analysis
      </Button>
    </div>
  )
}

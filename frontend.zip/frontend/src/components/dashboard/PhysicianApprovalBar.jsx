// components/dashboard/PhysicianApprovalBar.jsx — Human-in-the-loop clinical decision bar
import { useState, useEffect } from 'react'
import { Stethoscope, CheckCircle, AlertTriangle, UserCheck } from 'lucide-react'
import { Button } from '../ui/Button'
import { toast } from '../ui/Toast'
import { cn } from '../../lib/cn'

export function PhysicianApprovalBar({ result, onDecide, onAuditRefresh }) {
  const [deciding, setDeciding] = useState(null)
  const [verdict, setVerdict] = useState(null)
  const [error, setError] = useState(null)

  // Track result changes
  useEffect(() => {
    if (result) {
      if (result.physician_verdict) {
        setVerdict({ audit_id: result.audit_id, choice: result.physician_verdict })
      } else {
        setVerdict(null)
      }
      setError(null)
    } else {
      setVerdict(null)
      setError(null)
    }
  }, [result?.audit_id, result?.physician_verdict])

  if (!result) return null

  async function handleChoice(choice) {
    setDeciding(choice)
    setError(null)
    try {
      const resp = await onDecide(choice)
      const finalVerdict = { audit_id: resp?.audit_id || result.audit_id, choice }
      setVerdict(finalVerdict)
      toast.success(
        choice === 'approved' ? 'Recommendation Approved' : 'Clinical Override Recorded',
        `Physician decision saved to immutable audit trail for Patient ${result.patient_id}.`
      )
      if (onAuditRefresh) onAuditRefresh()
    } catch (err) {
      const msg = err.message || 'Failed to submit clinical decision'
      setError(msg)
      toast.error('Decision Submission Failed', msg)
    } finally {
      setDeciding(null)
    }
  }

  return (
    <div className="card slide-up">
      <div className="card-header" style={{ marginBottom: 'var(--sp-4)' }}>
        <div className="card-title-row">
          <div className="card-eyebrow">
            <span className="card-eyebrow-dot dot-green" />
            Human-in-the-Loop Governance
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: '0.72rem', color: 'var(--text-muted)' }}>
          <UserCheck size={13} />
          Attending Physician Review
        </div>
      </div>

      <div className="physician-bar">
        <div className="physician-bar-header">
          <Stethoscope size={16} style={{ color: 'var(--accent)' }} />
          <div className="physician-bar-title">CLINICAL VERDICT REQUIRED</div>
          <div className="physician-bar-id">Case #{result.patient_id || result.audit_id}</div>
        </div>

        {verdict ? (
          <div>
            <div className={cn('verdict-display', verdict.choice)}>
              {verdict.choice === 'approved' ? (
                <>
                  <CheckCircle size={18} />
                  <span>Approved by Attending Physician</span>
                </>
              ) : (
                <>
                  <AlertTriangle size={18} />
                  <span>Clinical Override Submitted by Physician</span>
                </>
              )}
            </div>
            <p style={{ marginTop: 10, fontSize: '0.76rem', color: 'var(--text-muted)' }}>
              Verdict permanently committed to SHA-256 audit log at {new Date().toLocaleTimeString()}.
            </p>
          </div>
        ) : (
          <>
            <p className="physician-bar-desc">
              Review multi-agent risk tier (<strong>{result.predicted_risk}</strong>) and safety agent recommendations above. Confirm approval to proceed with automated triage or submit a clinical override.
            </p>

            <div className="physician-btn-row">
              <Button
                id="approve-btn"
                variant="primary"
                onClick={() => handleChoice('approved')}
                loading={deciding === 'approved'}
                disabled={!!deciding}
                style={{
                  background: 'var(--risk-normal)',
                  borderColor: 'var(--risk-normal)',
                  color: '#ffffff',
                }}
              >
                <CheckCircle size={15} />
                Approve Recommendation
              </Button>

              <Button
                id="override-btn"
                variant="ghost"
                onClick={() => handleChoice('overridden')}
                loading={deciding === 'overridden'}
                disabled={!!deciding}
                style={{
                  color: 'var(--risk-warning)',
                  borderColor: 'var(--risk-warning-border)',
                  background: 'var(--risk-warning-bg)',
                }}
              >
                <AlertTriangle size={15} />
                Override Pipeline
              </Button>
            </div>
          </>
        )}

        {error && (
          <div style={{ marginTop: 12 }} className="error-banner">
            <span>⚠</span>
            <span>{error}</span>
          </div>
        )}
      </div>
    </div>
  )
}
export default PhysicianApprovalBar

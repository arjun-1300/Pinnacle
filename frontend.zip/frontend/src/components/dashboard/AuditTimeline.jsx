// components/dashboard/AuditTimeline.jsx — Live audit log table & clinical trial records
import { useEffect, useRef } from 'react'
import { RotateCw, ShieldCheck, ShieldAlert, Clock, Database } from 'lucide-react'
import { RiskBadge, VerdictBadge } from '../ui/Badge'
import { Button } from '../ui/Button'
import { Spinner } from '../ui/Spinner'

function formatTime(iso) {
  if (!iso) return '—'
  try {
    const d = new Date(iso)
    return d.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    })
  } catch {
    return '—'
  }
}

function formatDate(iso) {
  if (!iso) return ''
  try {
    const d = new Date(iso)
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  } catch {
    return ''
  }
}

export function AuditTimeline({ entries = [], loading = false, onRefresh }) {
  const timerRef = useRef(null)

  useEffect(() => {
    if (onRefresh) {
      onRefresh()
      timerRef.current = setInterval(onRefresh, 10000)
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [onRefresh])

  return (
    <div className="card">
      <div className="card-header">
        <div className="card-title-row">
          <div className="card-eyebrow">
            <span className="card-eyebrow-dot dot-purple" />
            Audit Trail & Regulatory Compliance
          </div>
          {entries.length > 0 && (
            <span
              style={{
                fontSize: '0.68rem',
                fontWeight: 800,
                padding: '2px 9px',
                borderRadius: 'var(--r-full)',
                background: 'var(--accent-glow)',
                color: 'var(--accent-light)',
                border: '1px solid rgba(99, 102, 241, 0.3)',
              }}
            >
              {entries.length} {entries.length === 1 ? 'record' : 'records'}
            </span>
          )}
        </div>

        <Button
          id="refresh-audit-btn"
          variant="ghost"
          size="sm"
          onClick={onRefresh}
          disabled={loading}
          style={{ height: 32, padding: '0 12px', fontSize: '0.74rem' }}
        >
          {loading ? (
            <>
              <Spinner size="sm" />
              <span>Syncing…</span>
            </>
          ) : (
            <>
              <RotateCw size={13} />
              <span>Sync Trail</span>
            </>
          )}
        </Button>
      </div>

      {entries.length === 0 ? (
        <div className="audit-empty-state">
          <Database size={36} style={{ opacity: 0.35, color: 'var(--accent)' }} />
          <p>
            No clinical records logged yet.<br />
            Execute a multi-agent triage analysis to generate immutable audit entries.
          </p>
        </div>
      ) : (
        <div className="audit-table-wrap">
          <div className="audit-table-header">
            <span>#</span>
            <span>Timestamp</span>
            <span>Patient ID</span>
            <span>Clinical Vitals & Medication</span>
            <span>Risk Tier</span>
            <span>Conf.</span>
            <span>Safety Status</span>
            <span>Physician Verdict</span>
          </div>

          <div className="audit-table-body">
            {entries.map((entry, index) => {
              const blocked = entry.drug_blocked
              const vitals = entry.vitals || {}

              return (
                <div key={entry.audit_id || index} className="audit-row">
                  <div className="audit-idx">{entries.length - index}</div>

                  <div>
                    <div className="audit-time">
                      <Clock size={11} style={{ color: 'var(--text-muted)' }} />
                      <span>{formatTime(entry.timestamp)}</span>
                    </div>
                    <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)', marginLeft: 16 }}>
                      {formatDate(entry.timestamp)}
                    </div>
                  </div>

                  <div>
                    <span className="audit-patient">#{entry.patient_id || 'UNKNOWN'}</span>
                  </div>

                  <div className="audit-vitals-summary">
                    {vitals.heart_rate != null && (
                      <span className="audit-vital-pill">HR: {vitals.heart_rate}</span>
                    )}
                    {vitals.spo2 != null && (
                      <span className="audit-vital-pill">SpO₂: {vitals.spo2}%</span>
                    )}
                    {vitals.temperature != null && (
                      <span className="audit-vital-pill">Temp: {vitals.temperature}°C</span>
                    )}
                    {vitals.systolic_bp != null && (
                      <span className="audit-vital-pill">SBP: {vitals.systolic_bp}</span>
                    )}
                    {entry.candidate_drug && (
                      <span
                        className={`audit-drug-cell ${blocked ? 'struck' : ''}`}
                        style={{ marginLeft: 4 }}
                      >
                        Rx: {entry.candidate_drug}
                      </span>
                    )}
                  </div>

                  <div>
                    <RiskBadge risk={entry.predicted_risk} />
                  </div>

                  <div style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 800, fontSize: '0.82rem' }}>
                    {entry.confidence != null ? `${Math.round(entry.confidence * 100)}%` : '—'}
                  </div>

                  <div>
                    {blocked ? (
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: 5,
                          fontSize: '0.74rem',
                          fontWeight: 700,
                          color: '#f87171',
                        }}
                      >
                        <ShieldAlert size={14} />
                        Blocked
                      </span>
                    ) : (
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: 5,
                          fontSize: '0.74rem',
                          fontWeight: 700,
                          color: '#34d399',
                        }}
                      >
                        <ShieldCheck size={14} />
                        Clear
                      </span>
                    )}
                  </div>

                  <div>
                    <VerdictBadge verdict={entry.physician_verdict} />
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
export default AuditTimeline

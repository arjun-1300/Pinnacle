// components/dashboard/AgentRiskCard.jsx — Multi-agent triage display
import { TrendingUp, Activity, ChevronRight } from 'lucide-react'
import { cn } from '../../lib/cn'

const RISK_CONFIG = {
  Normal:   { icon: '💚', heroClass: 'risk-normal',   label: 'Low Risk',      dotClass: 'dot-green' },
  Warning:  { icon: '⚠️',  heroClass: 'risk-warning',  label: 'Moderate Risk', dotClass: 'dot-amber' },
  Critical: { icon: '🚨', heroClass: 'risk-critical',  label: 'Critical Alert',dotClass: 'dot-red'   },
}

function EmptyState() {
  return (
    <div className="risk-hero risk-empty">
      <div className="risk-icon-wrap">
        <span style={{ fontSize: '1.6rem' }}>🫀</span>
      </div>
      <div className="risk-info">
        <div className="risk-level-label" style={{ fontSize: '1rem', color: 'var(--text-muted)' }}>
          Awaiting Analysis
        </div>
        <div className="risk-patient-id">Submit vitals to run the agent pipeline</div>
      </div>
    </div>
  )
}

function VitalsStrip({ vitals }) {
  if (!vitals) return null
  const chips = [
    { val: vitals.heart_rate,  lbl: 'HR',   unit: 'bpm'  },
    { val: vitals.spo2,        lbl: 'SpO₂', unit: '%'    },
    { val: vitals.temperature, lbl: 'Temp', unit: '°C'   },
    { val: vitals.systolic_bp, lbl: 'SBP',  unit: 'mmHg' },
  ]
  return (
    <div className="vitals-strip">
      {chips.map(({ val, lbl, unit }) => (
        <div key={lbl} className="vital-chip">
          <div className="vital-chip-val">
            {typeof val === 'number' ? val.toFixed(val % 1 === 0 ? 0 : 1) : val}
          </div>
          <div className="vital-chip-unit">{unit}</div>
          <div className="vital-chip-lbl">{lbl}</div>
        </div>
      ))}
    </div>
  )
}

function ConfidenceBar({ value }) {
  const pct = Math.round((value ?? 0) * 100)
  return (
    <div className="conf-bar-wrap">
      <div className="conf-bar-meta">
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <TrendingUp size={11} /> Model Confidence
        </span>
        <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 800, color: 'var(--text-primary)' }}>
          {pct}%
        </span>
      </div>
      <div className="conf-bar">
        <div className="conf-bar-fill" style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}

function ActionsList({ actions, risk }) {
  if (!actions?.length) return null
  return (
    <div className="actions-list">
      {actions.map((action, i) => {
        const isCritical = action.startsWith('ALERT') || action.startsWith('Activate')
        return (
          <div key={i} className={cn('action-item', isCritical && risk === 'Critical' && 'action-item-critical')}>
            <ChevronRight size={13} className="action-item-bullet" />
            <span>
              <span style={{ fontSize: '0.7rem', fontWeight: 700, opacity: 0.6, textTransform: 'uppercase', letterSpacing: '0.06em', marginRight: 6 }}>
                {risk === 'Critical' ? '[Decision Agent]' : '[Monitoring]'}
              </span>
              {action}
            </span>
          </div>
        )
      })}
    </div>
  )
}

export function AgentRiskCard({ result }) {
  if (!result) {
    return (
      <div className="card animate-slide-up">
        <div className="card-header">
          <span className="card-eyebrow">
            <span className="card-eyebrow-dot dot-green" />
            Agent Assessment
          </span>
        </div>
        <EmptyState />
      </div>
    )
  }

  const cfg = RISK_CONFIG[result.predicted_risk] ?? RISK_CONFIG.Normal
  const pct = Math.round((result.confidence ?? 0) * 100)

  return (
    <div className="card animate-slide-up">
      <div className="card-header">
        <span className="card-eyebrow">
          <span className={cn('card-eyebrow-dot', cfg.dotClass)} />
          Multi-Agent Assessment
        </span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {result.llm_powered ? (
            <span className="badge badge-accent" style={{ fontSize: '0.64rem', padding: '2px 8px' }}>
              ✨ Gemini LLM
            </span>
          ) : (
            <span className="badge badge-pending" style={{ fontSize: '0.64rem', padding: '2px 8px' }}>
              Deterministic Rule Engine
            </span>
          )}
          <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
            {result.audit_id?.slice(0, 8)}…
          </span>
        </div>
      </div>

      {/* Risk hero */}
      <div className={cn('risk-hero', cfg.heroClass)}>
        <div className="risk-icon-wrap">
          <span>{cfg.icon}</span>
        </div>
        <div className="risk-info">
          <div className="risk-level-label">{cfg.label}</div>
          <div className="risk-patient-id">Patient {result.patient_id}</div>
        </div>
        <div className="risk-conf-block">
          <div className="risk-conf-pct">{pct}%</div>
          <div className="risk-conf-label">Confidence</div>
        </div>
      </div>

      {/* Vitals strip */}
      <VitalsStrip vitals={result.vitals} />

      {/* Confidence bar */}
      <ConfidenceBar value={result.confidence} />

      {/* Clinical Rationale (LLM or Heuristic Synthesis) */}
      {result.clinical_rationale && (
        <div style={{
          marginTop: 14,
          padding: '12px 14px',
          borderRadius: 'var(--r-md)',
          background: 'var(--bg-elevated)',
          border: '1px solid var(--border)',
          fontSize: '0.80rem',
          lineHeight: 1.5,
          color: 'var(--text-secondary)',
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 6,
          }}>
            <span style={{
              fontSize: '0.68rem',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '0.08em',
              color: result.llm_powered ? 'var(--accent-light)' : 'var(--text-muted)',
              display: 'flex',
              alignItems: 'center',
              gap: 5,
            }}>
              {result.llm_powered ? '✨ Gemini AI Clinical Synthesis' : '🤖 Heuristic Decision Logic'}
            </span>
            {result.llm_model && (
              <span style={{ fontSize: '0.64rem', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                {result.llm_model}
              </span>
            )}
          </div>
          {result.clinical_rationale}
        </div>
      )}

      {/* 4-Agent Pipeline Quick Status */}
      <div
        onClick={() => document.getElementById('multi-agent-pipeline')?.scrollIntoView({ behavior: 'smooth' })}
        style={{
          marginTop: 12,
          padding: '10px 12px',
          borderRadius: 'var(--r-md)',
          background: 'var(--bg-elevated)',
          border: '1px solid var(--border)',
          cursor: 'pointer',
          transition: 'all 0.2s ease',
        }}
        className="hover:border-accent"
      >
        <div style={{
          fontSize: '0.66rem',
          fontWeight: 800,
          textTransform: 'uppercase',
          letterSpacing: '0.07em',
          color: 'var(--text-muted)',
          marginBottom: 8,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <span>Multi-Agent System Telemetry</span>
          <span style={{ color: 'var(--accent-light)', textDecoration: 'underline', fontSize: '0.64rem' }}>
            View Full Agent Breakdown ↓
          </span>
        </div>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
          gap: 6,
        }}>
          {[
            {
              num: '1',
              name: 'Monitoring Agent',
              isLlm: result.agent_llm_status?.monitoring_agent,
              defaultTech: 'RandomForest ML',
              reasoning: result.monitoring_reasoning || 'Vital sign classification & organ stress analysis',
            },
            {
              num: '2',
              name: 'Medication Agent',
              isLlm: result.agent_llm_status?.medication_agent,
              defaultTech: 'DDI Rules Engine',
              reasoning: result.medication_reasoning || 'Pharmacovigilance & contraindication scan',
            },
            {
              num: '3',
              name: 'Decision Agent',
              isLlm: result.agent_llm_status?.decision_agent,
              defaultTech: 'Clinical Heuristic',
              reasoning: result.clinical_rationale || 'Intervention synthesis & candidate selection',
            },
            {
              num: '4',
              name: 'Safety Interceptor',
              isLlm: result.agent_llm_status?.safety_agent,
              defaultTech: 'Deterministic Gate',
              reasoning: result.safety_reasoning || 'Programmatic contraindication validation barrier',
            },
          ].map((ag) => (
            <div
              key={ag.name}
              style={{
                fontSize: '0.72rem',
                background: 'var(--bg-card)',
                padding: '6px 8px',
                borderRadius: 'var(--r-sm)',
                border: '1px solid var(--border)',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 2 }}>
                <span style={{ fontWeight: 700, color: 'var(--text-primary)', fontSize: '0.70rem' }}>
                  {ag.num}. {ag.name.replace(' Agent', '')}
                </span>
                {ag.isLlm ? (
                  <span style={{ color: 'var(--accent-light)', fontSize: '0.60rem', fontWeight: 800 }}>✨ LLM</span>
                ) : (
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.60rem' }}>{ag.defaultTech}</span>
                )}
              </div>
              <div
                style={{
                  color: 'var(--text-secondary)',
                  fontSize: '0.64rem',
                  lineHeight: 1.3,
                  display: '-webkit-box',
                  WebkitLineClamp: 2,
                  WebkitBoxOrient: 'vertical',
                  overflow: 'hidden',
                }}
                title={ag.reasoning}
              >
                {ag.reasoning}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Divider */}
      {result.suggested_actions?.length > 0 && (
        <>
          <div className="divider" />
          <div className="card-eyebrow" style={{ marginBottom: 12 }}>
            <span className="card-eyebrow-dot" />
            Clinical Recommendations
          </div>
          <ActionsList actions={result.suggested_actions} risk={result.predicted_risk} />
        </>
      )}
    </div>
  )
}

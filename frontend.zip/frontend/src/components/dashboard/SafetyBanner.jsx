// components/dashboard/SafetyBanner.jsx — Safety Agent interceptor callout
import { ShieldX, ShieldCheck, AlertTriangle } from 'lucide-react'
import { cn } from '../../lib/cn'

export function SafetyBanner({ result }) {
  if (!result) return null

  const blocked = result.drug_blocked
  const drug    = result.candidate_drug

  return (
    <div className={cn('safety-banner', blocked ? 'blocked' : 'safe')}>
      {/* Header */}
      <div className="safety-banner-head">
        <div className="safety-banner-icon">
          {blocked ? <ShieldX size={20} /> : <ShieldCheck size={20} />}
        </div>
        <div>
          <div className="safety-banner-title">
            {blocked
              ? 'Safety Agent — Drug Intercepted'
              : 'Safety Agent — Cleared'}
          </div>
          <div className="safety-banner-sub">
            {blocked
              ? 'Contraindicated medication removed from treatment plan'
              : 'No contraindications detected'}
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="safety-banner-body">
        {/* Full block description when drug is blocked */}
        {blocked && drug && (
          <div className="safety-interaction-row">
            <AlertTriangle size={15} style={{ color: 'var(--risk-critical)', flexShrink: 0 }} />
            <div>
              <strong style={{ color: 'var(--risk-critical)', display: 'block', marginBottom: 3 }}>
                [BLOCKED BY SAFETY AGENT]
              </strong>
              Severe bleeding/hemorrhage contraindication with active Warfarin therapy.
              Proposed medication <code style={{ textDecoration: 'line-through', color: 'var(--risk-critical)', background: 'transparent', border: 'none', padding: 0 }}>{drug}</code> removed.
              Forwarded for physician review.
            </div>
          </div>
        )}

        {/* Interaction warnings */}
        {result.interaction_warnings?.map((w, i) => (
          <div key={i} className="safety-interaction-row">
            <AlertTriangle size={14} style={{ flexShrink: 0, marginTop: 1 }} />
            <span>{w}</span>
          </div>
        ))}

        {/* Drug status strip */}
        {drug && (
          <div className="safety-drug-strip">
            <span className="safety-drug-label">Proposed drug:</span>
            {blocked
              ? <span className="drug-badge-blocked">🚫 {drug}</span>
              : <span className="drug-badge-approved">✓ {drug}</span>
            }
            {result.final_drug && result.final_drug !== drug && (
              <>
                <span className="safety-drug-label">→ Final:</span>
                <span className="drug-badge-approved">✓ {result.final_drug}</span>
              </>
            )}
          </div>
        )}

        {/* Physician safety note */}
        {result.physician_notes?.length > 0 && (
          <div className="safety-physician-note">
            {result.physician_notes[0]}
          </div>
        )}

        {/* Safety Agent Reasoning */}
        {result.safety_reasoning && (
          <div style={{
            fontSize: '0.78rem',
            lineHeight: 1.5,
            color: 'var(--text-secondary)',
            background: 'rgba(0,0,0,0.25)',
            padding: '8px 12px',
            borderRadius: 'var(--r-sm)',
            borderLeft: blocked ? '3px solid var(--risk-critical)' : '3px solid var(--accent)',
            marginTop: 6,
          }}>
            <span style={{ fontWeight: 700, color: 'var(--text-primary)', marginRight: 6 }}>
              {result.agent_llm_status?.safety_agent ? '✨ LLM Safety Audit:' : '🛡️ Gatekeeper Audit:'}
            </span>
            {result.safety_reasoning}
          </div>
        )}

        {/* Allergy warnings */}
        {result.avoid_list?.length > 0 && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <span className="safety-drug-label">Contraindication list:</span>
            {result.avoid_list.map(d => (
              <span key={d} className="drug-badge-blocked" style={{ textDecoration: 'none' }}>
                {d}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

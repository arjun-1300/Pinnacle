// pages/DashboardPage.jsx — Clinical Command Center Dashboard
import { useState, useCallback, useEffect } from 'react'
import { api } from '../api'
import { AppShell } from '../components/layout/AppShell'
import { Navbar } from '../components/layout/Navbar'
import { VitalsForm } from '../components/dashboard/VitalsForm'
import { AgentRiskCard } from '../components/dashboard/AgentRiskCard'
import { SafetyBanner } from '../components/dashboard/SafetyBanner'
import { PhysicianApprovalBar } from '../components/dashboard/PhysicianApprovalBar'
import { MultiAgentPipelineSection } from '../components/dashboard/MultiAgentPipelineSection'
import { AuditTimeline } from '../components/dashboard/AuditTimeline'
import { ToastContainer, toast } from '../components/ui/Toast'

export function DashboardPage() {
  const [result, setResult] = useState(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [error, setError] = useState(null)
  const [auditEntries, setAuditEntries] = useState([])
  const [auditLoading, setAuditLoading] = useState(false)
  const [serverOnline, setServerOnline] = useState(false)

  // Initial health check
  useEffect(() => {
    api.health()
      .then(() => setServerOnline(true))
      .catch(() => setServerOnline(false))
  }, [])

  const refreshAudit = useCallback(async () => {
    setAuditLoading(true)
    try {
      const data = await api.audit()
      // Sort newest first if backend sends chronological
      const sorted = Array.isArray(data) ? [...data].reverse() : []
      setAuditEntries(sorted)
    } catch {
      /* Backend offline or unreachable */
    } finally {
      setAuditLoading(false)
    }
  }, [])

  async function handleAnalyze(payload) {
    setAnalyzing(true)
    setError(null)
    try {
      const data = await api.analyze(payload)
      setResult(data)
      setServerOnline(true)

      if (data.drug_blocked) {
        toast.error(
          'Safety Interceptor Triggered',
          `Prescription blocked: ${data.candidate_drug || 'contraindicated agent'}.`
        )
      } else {
        toast.success(
          'Analysis Completed',
          `Risk assessed as ${data.predicted_risk} (${Math.round((data.confidence || 0) * 100)}% conf).`
        )
      }

      refreshAudit()
    } catch (err) {
      const msg = err.message || 'Analysis request failed'
      setError(msg)
      setServerOnline(false)
      toast.error('Pipeline Execution Error', msg)
    } finally {
      setAnalyzing(false)
    }
  }

  async function handleDecide(choice) {
    const data = await api.decide(choice)
    setServerOnline(true)
    refreshAudit()
    return data
  }

  return (
    <AppShell navbar={<Navbar serverOnline={serverOnline} />}>
      <div className="dashboard-container">
        {/* Top 2-Column Balanced Grid: Left (40%) / Right (60%) */}
        <div className="dashboard-grid">
          {/* Left Column (40%): Patient Input Card */}
          <div className="dashboard-left">
            <VitalsForm onAnalyze={handleAnalyze} loading={analyzing} />

            {error && (
              <div className="error-banner">
                <span>⚠</span>
                <span>{error}</span>
              </div>
            )}
          </div>

          {/* Right Column (60%): Assessment, Recommendations, Safety & Physician Bar */}
          <div className="dashboard-right">
            <AgentRiskCard result={result} />
            <SafetyBanner result={result} />
            <PhysicianApprovalBar
              result={result}
              onDecide={handleDecide}
              onAuditRefresh={refreshAudit}
            />
          </div>
        </div>

        {/* 4-Agent Autonomous Pipeline Full Breakdown */}
        <MultiAgentPipelineSection result={result} />

        {/* Full-width Bottom Section: Audit Trail & Compliance Data Table */}
        <div className="dashboard-bottom">
          <AuditTimeline
            entries={auditEntries}
            loading={auditLoading}
            onRefresh={refreshAudit}
          />
        </div>
      </div>

      <ToastContainer />
    </AppShell>
  )
}
export default DashboardPage
